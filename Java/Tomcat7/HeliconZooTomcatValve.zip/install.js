/*
1. search tomcat install path
2. copy zoo valve jar into tomcat libs
3. register zoo valve
4. restart tomcat
*/

var RAILO_REG_PATH          = 'HKLM\\SOFTWARE\\Vivio Technologies\\Railo\\Location';
var RAILO_REG_PATH_WOW6432  = 'HKLM\\SOFTWARE\\Wow6432Node\\Vivio Technologies\\Railo\\Location';

var TOMCAT_REG_PATH         = 'HKLM\\SOFTWARE\\Apache Software Foundation\\Tomcat\\7.0\\Tomcat7\\InstallPath';
var TOMCAT_REG_PATH_WOW6432 = 'HKLM\\SOFTWARE\\Wow6432Node\\Apache Software Foundation\\Tomcat\\7.0\\Tomcat7\\InstallPath';

var FILE_READING = 1;
var FILE_WRITING = 2;

ZOO_VALVE_TAG = '<Valve className="com.helicontech.zoo.tomcat.ZooServerValve" />';
TOMCAT_ADMIN_TAGS = '<role rolename="admin-gui"/>\r\n<user username="admin" password="admin" roles="admin-gui"/>';



function _copyFile(f1, f2) {
  WriteLog("copy file: '" + f1 + "' to '" + f2 + "'");
  var fso = new ActiveXObject("Scripting.FileSystemObject");
  f = fso.GetFile(f1);
  f.Copy(f2);
}

function _fileExists(filename){
  var fso = new ActiveXObject("Scripting.FileSystemObject");
  return fso.FileExists(filename);
}

function searchInRegistry(paths) {
  //WriteLog("searchInRegistry: begin");
  var wsh = getShell();
  var result = '';
  for(var i = 0; i < paths.length; i++){
    try {
      result = wsh.RegRead(paths[i]);
      if (result) {
          WriteLog("searchInRegistry: result=" + result);
        break;
      }
    } catch (e) {
        WriteLog("searchInRegistry: error " + e.message);

    }

    //WriteLog("searchInRegistry: done");
  }

  return result;
}

function copyZooValve(zooValvePath, tomcatFolder) {
  var tomcatLibFolder = tomcatFolder + '\\lib\\';
  _copyFile(zooValvePath, tomcatLibFolder);
  WriteLog('Zoo valve copied to Tomcat lib folder');
}

function enableZooValve(tomcatFolder){
  var tomcatServerConf = tomcatFolder + '\\conf\\server.xml';
  var fso = new ActiveXObject('Scripting.FileSystemObject');
  var f = fso.OpenTextFile(tomcatServerConf, FILE_READING);
  var text = f.ReadAll()
  f.Close();

  // check the valve is not installed
  WriteLog("search");
  var pos = text.search(ZOO_VALVE_TAG);
  WriteLog("position:"+pos);
  if (pos == -1){
    // add valve record before </Engine> tag
    text = text.replace(/(\s*\<\/Engine\>)/ig, '\r\n      '+ZOO_VALVE_TAG+'\r\n$1');
    
    // save server.xml
    f = fso.OpenTextFile(tomcatServerConf, FILE_WRITING);
    f.Write(text);
    f.Close();
    WriteLog('Zoo valve registered in tomcat server config');
  } else {
    WriteLog('Warning: Zoo valve already registered in tomcat server config');
  }
  
}

function backupServerConfig(tomcatFolder){
  var tomcatConfFolder = tomcatFolder + '\\conf\\';
  if (!_fileExists(tomcatConfFolder + 'server~original.xml')){
    _copyFile(tomcatConfFolder + 'server.xml', tomcatConfFolder + 'server~original.xml');
    WriteLog('server.xml backed up');
  } else {
    WriteLog('Warning: server.xml backup already exists');
  }
}

function revertServerConfig(tomcatFolder){
  var tomcatConfFolder = tomcatFolder + '\\conf\\';
  _copyFile(tomcatConfFolder + 'server~original.xml', tomcatConfFolder + 'server.xml');
}

function fixServerConfig(tomcatFolder){
  var tomcatServerConf = tomcatFolder + '\\conf\\server.xml';
  var fso = new ActiveXObject('Scripting.FileSystemObject');
  var f = fso.OpenTextFile(tomcatServerConf, FILE_READING);
  var text = f.ReadAll()
  f.Close();

  text = text.replace(/<Server\s+port="\d+"\s+shutdown="SHUTDOWN">/ig, '<Server port="8105" shutdown="SHUTDOWN">');
  text = text.replace(/<Connector\s+port="\d+"\s+protocol="HTTP\/1\.1"/ig, '<Connector port="8180" protocol="HTTP/1.1"');
  text = text.replace(/<Connector\s+port="\d+"\s+protocol="AJP\/1\.3"/ig,  '<Connector port="8109" protocol="AJP/1.3"');

  // check the valve is not installed
  var pos = text.search(ZOO_VALVE_TAG);
  if (pos == -1){
    // add valve record before </Engine> tag
    text = text.replace(/(\s*\<\/Engine\>)/ig, '\r\n      '+ZOO_VALVE_TAG+'\r\n$1');
    WriteLog('Zoo valve registered in tomcat server config');
  } else {
    WriteLog('Warning: Zoo valve already registered in tomcat server config');
  }

  f = fso.OpenTextFile(tomcatServerConf, FILE_WRITING);
  f.Write(text);
  f.Close();
  WriteLog('Server config updated with shutdown port 8105, http port 8180, ajp port 8109');
}

function setJavaHome(){
  // get from registry path jdk 1.6 or jdk 1.7 or jdk 1.5
  var shell = getShell();

  function getJavaHome(ver){
    var javaHome = '';
    try {
      javaHome = shell.RegRead('HKLM\\SOFTWARE\\JavaSoft\\Java Development Kit\\'+ver+'\\JavaHome');
    } catch(err) {}
    return javaHome;
  }

  var javaHome = getJavaHome('1.8');
  if (!javaHome) {
	javaHome = getJavaHome('1.7');
	  if (!javaHome) {
		javaHome = getJavaHome('1.6');
		if (!javaHome){
		  javaHome = getJavaHome('1.5');
		  if (!javaHome){
			WScript.StdErr.WriteLine('Oracle JDK not found. Supported versions: JDK 5, 6, 7, 8\n');
			WScript.Quit(1);
		  }
		}
	  }
  }

  WScript.StdErr.WriteLine('JDK found: '+javaHome);

  // update system JAVA_HOME env with jdk path
  var envs = shell.Environment('SYSTEM');
  var existingJavaHome = envs("JAVA_HOME");
  if (existingJavaHome){
      WriteLog('Existing JAVA_HOME env: ' + existingJavaHome);
      WriteLog('System JAVA_HOME not changed');
  } else{
    envs("JAVA_HOME") =  javaHome;
    WriteLog('System JAVA_HOME updated to ' + javaHome);
  }
}

function backupTomcatUsersConfig(tomcatFolder){
  var tomcatConfFolder = tomcatFolder + '\\conf\\';
  if (!_fileExists(tomcatConfFolder + 'tomcat-users~original.xml')){
    _copyFile(tomcatConfFolder + 'tomcat-users.xml', tomcatConfFolder + 'tomcat-users~original.xml');
    WriteLog('tomcat-users.xml backed up');
  } else {
    WriteLog('Warning: tomcat-users.xml backup already exists');
  }
}

function revertTomcatUsersConfig(tomcatFolder){
  var tomcatConfFolder = tomcatFolder + '\\conf\\';
  if (_fileExists(tomcatConfFolder + 'tomcat-users~original.xml')){
    _copyFile(tomcatConfFolder + 'tomcat-users~original.xml', tomcatConfFolder + 'tomcat-users.xml');
  }
}

function setAdminPassword(tomcatFolder){
  var tomcatUsers = tomcatFolder + '\\conf\\tomcat-users.xml';
  var fso = new ActiveXObject('Scripting.FileSystemObject');
  var f = fso.OpenTextFile(tomcatUsers, FILE_READING);
  var text = f.ReadAll()
  f.Close();

  // check user record exist
  var pos = text.search(TOMCAT_ADMIN_TAGS);
  if (pos == -1){
    text = text.replace(/(\s*\<\/tomcat-users\>)/ig, ''+TOMCAT_ADMIN_TAGS+'\r\n$1');
    f = fso.OpenTextFile(tomcatUsers, FILE_WRITING);
    f.Write(text);
    f.Close();
    WriteLog('Tomcat users config updated');
  } else {
    WriteLog('Warning: Tomcat users config already updated');
  }
}

var SW_HIDE = 0;
var SW_SHOWNORMAL = 1;

function restartRailo() {
  WriteLog('Railo tomcat service begin restart');
  WriteLog(Exec("cmd /c net stop Railo && net start Railo"));
  //var shell = getShell();
  ///shell.Run("cmd /c net stop Railo && net start Railo", SW_HIDE, true /* bWaitOnReturn */);
  WriteLog('Railo tomcat service restarted');
}

function installTomcatService(tomcatFolder){
  var shell = getShell();
  shell.Run("cmd /c cd " + tomcatFolder + "\\bin && service.bat install tomcat7", SW_HIDE, true /* bWaitOnReturn */);
  shell.Run("cmd /c cd " + tomcatFolder + "\\bin && tomcat7.exe //US//tomcat7 --Startup=auto", SW_HIDE, true /* bWaitOnReturn */);
  WriteLog('tomcat7 service installed');
}

function uninstallTomcatService(tomcatFolder){
  var shell = getShell();
  shell.Run("cmd /c cd " + tomcatFolder + "\\bin && service.bat remove tomcat7", SW_HIDE, true /* bWaitOnReturn */);
  WriteLog('tomcat7 service removed');
}

function startTomcatService(){
  var shell = getShell();
  shell.Run("cmd /c net start tomcat7", SW_HIDE, true /* bWaitOnReturn */);
  WriteLog('tomcat7 service started');
}

function stopTomcatService(){
  var shell = getShell();
  shell.Run("cmd /c net stop tomcat7", SW_HIDE, true /* bWaitOnReturn */);
  WriteLog('tomcat7 service stoped');
}

function searchRailoInstallFolder() {
  var path = searchInRegistry(new Array(RAILO_REG_PATH, RAILO_REG_PATH_WOW6432));
  if (path) {
    path = path + '\\tomcat';
  }
  return path;
}

function searchTomcatInstallFolder() {
  var path = searchInRegistry(new Array(TOMCAT_REG_PATH, TOMCAT_REG_PATH_WOW6432));
  return path;
}

function installRailoTomcat(folder){
  backupServerConfig(folder);
  enableZooValve(folder);
}

function uninstallRailoTomcat(folder){
  revertServerConfig(folder);
  restartRailo();
}

function installTomcat(folder){
  backupServerConfig(folder);
  backupTomcatUsersConfig(folder);
  fixServerConfig(folder);
  setAdminPassword(folder);
  setJavaHome();
  installTomcatService(folder);
  startTomcatService();
}

function uninstallTomcat(folder){
  stopTomcatService();
  uninstallTomcatService(folder);
  revertTomcatUsersConfig(folder);
  revertServerConfig(folder);
}

function main() {

  if (WScript.Arguments.length == 1){
    var arg = WScript.Arguments(0);
    var folder;

    // railo
    if (arg == 'railo' || arg == '-railo'){
      folder = searchRailoInstallFolder();
      if (!folder){
          WriteLog('Could not find folder with railo');
          return 1;
      }
        WriteLog('Railo install path: ' + folder);

      if (arg == 'railo'){
         // install
        //copyZooValve('..\\dist\\HeliconZooTomcatValve.jar', folder);
        installRailoTomcat(folder);
      } else {
        // uninstall
        uninstallRailoTomcat(folder);
      }
    }



    /* tomcat */
    if (arg == 'tomcat' || arg == '-tomcat'){
      folder = searchTomcatInstallFolder();
      if (!folder){
        WriteLog('Could not find folder with tomcat');
        return 1;
      }
        
      WriteLog('Tomcat install path: ' + folder);

      if (arg == 'tomcat'){
        // install
        //copyZooValve('..\\dist\\HeliconZooTomcatValve.jar', folder);
        installTomcat(folder);
      } else {
        // uninstall
        uninstallTomcat(folder);
      }
    }
}

return 0; //OK
}



function WriteLogEx(message, show) {

    if (mode == "console") {
        WScript.Echo(message);
    }
    


//    if (mode == "msi") {

//        //var msiMessageTypeError = 0x04000000;
//        var msiMessageTypeError = 0x01000000;
//        var msiMessageTypeUser = 003000000;

//        var record = Session.Installer.CreateRecord(0);
//        record.StringData(0) = message;
//        var recordType = 0x04000000;
//        if (show)
//            recordType = msiMessageTypeError | msiMessageTypeUser

//        Session.Message(recordType, record);    
//    
//    }
}
//_____________________________________________________________________________/

function WriteLog(message) {
    return WriteLogEx(message, false);
}


function getShell(message, show) {

    if (mode == "console") {
        return WScript.CreateObject('WScript.Shell')
    }

    return null;
}



function Exec(command) {
    var shell = getShell();
    exec = shell.exec(command);
    var output = exec.StdOut.ReadAll();
    return output;

}


//var mode = "msi";
var mode = "console";

//try {
    WriteLog(Exec("cmd /c SET"));

    WriteLog("Setup: begin");

    exitCode = main();


    if (exitCode == 0) {
        WriteLog("Setup: OK");
    }
    else {
        WriteLog("Setup: FAILED");
        WScript.Quit(exitCode);
    }

//}
//catch (err) {
//    WriteLog("Error! Setup failed. Exception message: '" + err.message + "'");
//    WScript.Quit(1);
//}

