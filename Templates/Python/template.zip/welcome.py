import os.path

"""
   This is sample WSGI script. It simply returns content of
   static/zoo-index.html file to every request.
"""


def application(environ, start_response):
    root = os.path.dirname(__file__)
    welcome_path = os.path.join(root, 'static', 'zoo-index.html')
    start_response('200 OK', [('Content-type','text/html')])
    with open(welcome_path, 'rb') as f:
        yield f.read()
