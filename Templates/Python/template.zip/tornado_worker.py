import os
import tornado.wsgi
import tornado.httpserver
import welcome

"""
  This is sample HTTP worker based on Tornado server.
  To implement other HTTP worker please make sure it is listening on port
  provided in PORT environment variable or '--port' command line option.
"""


if __name__ == "__main__":
   container = tornado.wsgi.WSGIContainer(welcome.application)
   http_server = tornado.httpserver.HTTPServer(container)
   http_server.listen(int(os.environ['PORT']))
   tornado.ioloop.IOLoop.instance().start()