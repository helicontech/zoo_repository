use Mojolicious::Lite;

get '/' => sub { shift->render(text => '<h1>Hello from Mojolicious!</h1>') };

app->start;