print "Content-type: text/html\r\n\r\n";
print <<EndOfHTML;
<html><head><title>Perl Environment Variables</title></head>
<body>
<h1>Hello from Perl!</h1>
<h2>Perl CGI Environment Variables</h2>
<pre><code>
EndOfHTML

foreach $key (sort(keys %ENV)) {
    print "$key : $ENV{$key}\n";
}

print "</code></pre></body></html>";