use Dancer;
 
get '/' => sub {
      return 'Hello from Dancer!';
};

 
start;