 #!/usr/bin/perl
 {
 package MyWebServer;
 
 use HTTP::Server::Simple::CGI;
 use base qw(HTTP::Server::Simple::CGI);
 
  my $data;
  {
      my $file = 'index.html';
      local $/;
      open my $fh, '<', $file or die "can't open $file: $!";
      $data = <$fh>;
  }

  sub handle_request {
    my $self = shift;
    my $cgi  = shift;
    print "HTTP/1.0 200 OK\r\n".
	      $cgi->header,
		  $data;
  }
 
} 
 
 # start the server on port %PORT%
 my $pid = MyWebServer->new($ENV{"PORT"})->background();
 print "Use 'kill $pid' to stop server.\n";