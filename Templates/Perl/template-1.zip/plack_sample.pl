#!/usr/bin/perl
use strict;
use warnings;
 
my $app = sub {
  my $data;
  {
      my $file = 'index.html';
      local $/;
      open my $fh, '<', $file or die "can't open $file: $!";
      $data = <$fh>;
  }
  return [
    '200',
    [ 'Content-Type' => 'text/html' ],
	[ $data ],
  ];
};