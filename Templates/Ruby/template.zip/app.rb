require 'rack'


class App
  def call(env)
    app_path = File.dirname(__FILE__)
	file = File.open(app_path + "/public/zoo-index.html", "rb")
    [200, {"Content-Type" => "text/html"}, [file.read]]
  end
end
