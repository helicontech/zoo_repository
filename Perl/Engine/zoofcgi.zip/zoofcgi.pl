#
# Copyright (C) Helicon Tech, 2011.
#
# The code is partially based on Denis S. Filimonov's FastCGI wrapper (http://www.ruby-forum.com/topic/145858)
#

use FCGI;
use Win32::API;


&run;


# We must trap exit, otherwise CGI scripts will cause process restarting.
BEGIN {
    *CORE::GLOBAL::exit = sub {
        __debug__( "Script tried to exit" );
        next;
        };
}



# Also let's trap errors
sub errors_trap
{
    response_error( "$ENV{SCRIPT_FILENAME} returned error: $@" );
}
$SIG{'__DIE__'} = $SIG{'__WARN__'} = 'errors_trap';



sub response_error
{
    print "Status: 500\r\n";
    print "Content-Type: text/html;\r\n\r\n";
    
    ( $message ) = @_;
    __debug__( "500 Error: $message" );
    print "$message";
}



sub __debug__
{
    if ( !defined( $dbg ) )
        {
        $dbg = Win32::API->new( 'kernel32', 'OutputDebugStringA', 'P', 'V' );
        }
        
    ( $message ) = @_;    
    $dbg->Call( "[perl-worker] $message" );
}



sub run
{
    __debug__( '*** START ***' );
    
    from_pipe();
    
    __debug__( '*** FINISH ***' );
}



sub from_pipe
{
    __debug__( 'Pipe, single-threaded mode' );
    
    my $request = FCGI::Request( \*STDIN, \*STDOUT, \*STDERR, \%ENV );
    unless ( $request )
        {        
        response_error( "Couldn't create request" );
        return;
        }
        
    while ( $request->Accept() >= 0 )
        {
        # Current file name should be the same as script name,
        # otherwise some apps (AwStats) won't work.
        $0 = $ENV{SCRIPT_FILENAME};
        process_request();
        }
    
    $request->Finish();
}



sub from_sockets
{
    __debug__( 'Sockets, multi-threaded mode' );
    
    $socket = FCGI::OpenSocket( "0.0.0.0:9999", 100 );
    $request = FCGI::Request( \*STDIN, \*STDOUT, \*STDERR, \%ENV, $socket );
    
    # TODO...
        
    FCGI::CloseSocket( $socket );
}



sub process_request
{
    #__debug__( 'Request accepted' );
            
    my $script_file = $ENV{SCRIPT_FILENAME}; 
    
    # cd to the script's local directory
    if ( $script_file =~ /^(.*)\\[^\\]+$/ )
        {
        __debug__( "Chdir to $1" );
        chdir $1;
        }
    
    #__debug__( "Loading $script_file" );
    open( CODE_FILE, "<$script_file" ) or response_error("Cannot open file: $script_file");  #die "Cannot open file: $script_file"; 
    @code = <CODE_FILE>;
    
    #__debug__( 'Evaluating...' );
    
    eval
        {
        my $code_to_eval = join( "\r\n", @code );

        eval $code_to_eval;
        };
    
    #__debug__( 'Done' );    
}
